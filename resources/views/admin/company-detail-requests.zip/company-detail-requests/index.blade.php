@extends('admin.layouts.app')

@section('page_title', 'Company Detail Requests')

@section('content')
    <div class="card">
        <div class="card-header">
            <div class="d-flex align-items-start flex-wrap gap-3">
                <div>
                    <h2 class="card-title mb-1">Company Detail Requests</h2>
                    <p class="text-muted small mb-0">Leads submitted from the frontend "Get details now" form.</p>
                </div>

                <form method="GET" class="profile-filters">
                    <div class="filter-field filter-search">
                        <label class="filter-label" for="search-filter">Search</label>
                        <div class="filter-search-input">
                            <input id="search-filter" type="search" name="search" class="form-control"
                                   placeholder="Name, mobile, email, location, company" value="{{ $filters['search'] ?? '' }}">
                            <button class="btn btn-primary" type="submit">
                                <i class="fas fa-filter me-1"></i>
                                Filter
                            </button>
                        </div>
                    </div>

                    <div class="filter-field" style="min-width: 120px;">
                        <label class="filter-label">&nbsp;</label>
                        <a href="{{ route('admin.company-detail-requests.index') }}" class="btn btn-link" style="padding: 8px 0;">Reset</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Email</th>
                            <th>Company</th>
                            <th>Submitted</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($requests as $request)
                            <tr>
                                <td>
                                    <div class="fw-semibold">{{ $request->name }}</div>
                                    @if($request->location)
                                        <div class="text-muted small">{{ $request->location }}</div>
                                    @endif
                                </td>
                                <td>{{ $request->mobile_number }}</td>
                                <td>{{ $request->email ?: '—' }}</td>
                                <td>
                                    @if($request->company)
                                        <div class="fw-semibold">{{ $request->company->owner_name ?? 'Company' }}</div>
                                        <div class="text-muted small">#{{ $request->company->id }}</div>
                                    @else
                                        —
                                    @endif
                                </td>
                                <td>
                                    <div>{{ $request->created_at?->format('d M Y, h:i A') }}</div>
                                    <div class="text-muted small">Updated {{ $request->updated_at?->diffForHumans() }}</div>
                                </td>
                                <td class="text-end">
                                    <a href="{{ route('admin.company-detail-requests.show', $request) }}" class="btn btn-sm btn-outline-primary">
                                        View
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No company detail requests found.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if($requests->hasPages())
            <div class="card-footer">
                {{ $requests->links() }}
            </div>
        @endif
    </div>
@endsection
