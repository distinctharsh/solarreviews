@extends('admin.layouts.app')

@section('page_title', 'Company Detail Request')

@section('content')
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
        <div>
            <h2 class="mb-1">Request #{{ $request->id }}</h2>
            <div class="text-muted small">Submitted {{ $request->created_at?->format('d M Y, h:i A') }}</div>
        </div>
        <a href="{{ route('admin.company-detail-requests.index') }}" class="btn btn-outline-secondary">
            Back
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <div class="text-muted small">Name</div>
                    <div class="fw-semibold">{{ $request->name }}</div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="text-muted small">Mobile</div>
                    <div class="fw-semibold">{{ $request->mobile_number }}</div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="text-muted small">Email</div>
                    <div class="fw-semibold">{{ $request->email ?: '—' }}</div>
                </div>
                <div class="col-md-6 mb-3">
                    <div class="text-muted small">Location</div>
                    <div class="fw-semibold">{{ $request->location ?: '—' }}</div>
                </div>
                <div class="col-md-12 mb-3">
                    <div class="text-muted small">Company</div>
                    @if($request->company)
                        <div class="fw-semibold">{{ $request->company->owner_name ?? 'Company' }}</div>
                        <div class="text-muted small">
                            #{{ $request->company->id }}
                            @if($request->company->website_url)
                                &middot; {{ $request->company->website_url }}
                            @endif
                        </div>
                    @else
                        <div class="fw-semibold">—</div>
                    @endif
                </div>
                <div class="col-md-12">
                    <div class="text-muted small">Message</div>
                    <div class="fw-semibold" style="white-space: pre-wrap;">{{ $request->message ?: '—' }}</div>
                </div>
            </div>
        </div>
    </div>
@endsection
